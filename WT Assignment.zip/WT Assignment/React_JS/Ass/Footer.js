import React from 'react';
import './Footer.css';

function Footer()
{
    return(
        <footer className="Footer">
            <h1>
            
             <marquee> All Resverd </marquee>
             </h1>
             </footer>
    );
};
export default Footer;